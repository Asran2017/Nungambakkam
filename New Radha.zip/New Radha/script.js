if (ranjani === 1) {
  console.log(ranjani);
}
